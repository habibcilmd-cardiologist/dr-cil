
	import * as THREE from 'https://cdn.skypack.dev/three@0.132.2';
	import { GLTFLoader } from 'https://cdn.skypack.dev/three@0.132.2/examples/jsm/loaders/GLTFLoader.js';
	import { OrbitControls } from 'https://cdn.skypack.dev/three@0.132.2/examples/jsm/controls/OrbitControls.js';

	const container = document.getElementById('heart-viewer');
	const loadingText = document.getElementById('heart-loading');

	// Update text colors for white background
	loadingText.style.color = '#333';
	document.querySelector('#heart-viewer > div:last-child').style.color = 'rgba(0,0,0,0.6)';

	// Scene setup
	const scene = new THREE.Scene();
	scene.background = new THREE.Color(0xffffff); // White background
	// Update fog to match background
	scene.fog = new THREE.Fog(0xffffff, 20, 100);

	const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
	camera.position.z = 5;
	camera.position.y = 0;

	const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
	renderer.setSize(container.clientWidth, container.clientHeight);
	renderer.setPixelRatio(window.devicePixelRatio);
	// Enable shadow map for better realism
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = THREE.PCFSoftShadowMap;
	// Output encoding to sRGB for better color accuracy with GLTF
	renderer.outputEncoding = THREE.sRGBEncoding;
	container.appendChild(renderer.domElement);

	// Controls
	const controls = new OrbitControls(camera, renderer.domElement);
	controls.enableDamping = true;
	controls.dampingFactor = 0.05;
	controls.enableZoom = true;
	controls.autoRotate = true;
	controls.autoRotateSpeed = 1.0;

	// Lights
	const ambientLight = new THREE.AmbientLight(0xffffff, 1.2); // Bright ambient
	scene.add(ambientLight);

	const dirLight = new THREE.DirectionalLight(0xffffff, 1.5); // Main sun light
	dirLight.position.set(5, 10, 7);
	dirLight.castShadow = true;
	scene.add(dirLight);

	const fillLight = new THREE.DirectionalLight(0xE3E3E3, 1.0); // Fill light from opposite side
	fillLight.position.set(-5, 0, 5);
	scene.add(fillLight);

	// Load Model
	const loader = new GLTFLoader();
	loader.load('/models/istanbul-kardiyolog-dr-habib-cil.glb', (gltf) => {
	    const object = gltf.scene;

	    // Bounding box
	    const box = new THREE.Box3().setFromObject(object);
	    const size = box.getSize(new THREE.Vector3());
	    const center = box.getCenter(new THREE.Vector3());

	    // Center model
	    object.position.sub(center);
	    scene.add(object);

	    // ✅ KAMERAYI GERİ AL (TEK DOĞRU YÖNTEM)
	    const maxDim = Math.max(size.x, size.y, size.z);
	    const fov = camera.fov * (Math.PI / 180);

	    let cameraZ = (maxDim / 2) / Math.tan(fov / 2);
	    cameraZ *= 2.2; // 🔥 BUNU 2.2 – 3.0 arası değiştir

	    camera.position.set(0, 0, cameraZ);

	    camera.near = cameraZ / 100;
	    camera.far = cameraZ * 100;
	    camera.updateProjectionMatrix();

	    // ✅ ORBIT CONTROLS'U RESETLE
	    controls.target.set(0, 0, 0);
	    controls.minDistance = cameraZ * 0.6;
	    controls.maxDistance = cameraZ * 2.5;
	    controls.update();

	    loadingText.style.display = 'none';
	});


	}, function (xhr) {
	    if (xhr.lengthComputable) {
	        const percentComplete = xhr.loaded / xhr.total * 100;
	        loadingText.innerText = `Loading... ${Math.round(percentComplete)}%`;
	    }
	}, function (error) {
	    console.error('An error happened', error);
	    loadingText.innerText = 'Error loading model';
	    loadingText.style.color = 'red';
	});

	// Animation Loop
	function animate() {
	    requestAnimationFrame(animate);
	    controls.update();
	    renderer.render(scene, camera);
	}

	animate();

	// Handle Resize
	window.addEventListener('resize', function () {
	    if (container) {
	        camera.aspect = container.clientWidth / container.clientHeight;
	        camera.updateProjectionMatrix();
	        renderer.setSize(container.clientWidth, container.clientHeight);
	    }
	});
